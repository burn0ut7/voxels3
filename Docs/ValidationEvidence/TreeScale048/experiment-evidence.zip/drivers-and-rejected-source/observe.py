import base64, datetime, json, os, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / '.codex/tree-performance'))
from measure import native, call, diagnostic, source

OUT = ROOT / 'Docs/ValidationEvidence/TreeScale048'
OUT.mkdir(parents=True, exist_ok=True)
TREE = '8ecd0810-19a7-4b29-be95-792f0de4145f'
POSES = {
    'close': ('-1864,-1864,250.125', '-35,45,0'),
    'near': ('-2110,-2110,350', '-8,45,0'),
    'far': ('-2500,-2500,470', '6.3,45,0'),
}
label, pose = sys.argv[1:3]
width, height = (923, 510) if os.environ.get('TREE_HALF_RES') == '1' else (1846, 1019)
stages = sys.argv[3:] or ['on', 'off', 'restored']
position, angles = POSES[pose]
result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source': source(), 'stages': []}
path = OUT / (label + '-' + pose + '.json')

def save():
    path.write_text(json.dumps(result, indent=2), encoding='utf-8')

def check():
    camera = native('get_ejected_camera')
    assert all(abs(float(a)-float(b)) < 0.02 for key,value in [('Position',position),('Angles',angles)] for a,b in zip(camera[key].split(','), value.split(','))), 'Camera moved; stopping'
    assert abs(camera['RenderWidth']-width*1.5)<1 and abs(camera['RenderHeight']-height*1.5)<1, camera
    return camera

native('set_editor_camera_ejected', {'ejected': True})
native('set_ejected_camera', {'position': position, 'angles': angles, 'fieldOfView': 60})
native('set_game_render_resolution', {'width': width, 'height': height})
original = native('get_game_object', {'id': TREE, 'includeComponentProperties': True})
assert original['Enabled']
result['original'] = original
native('console_command', {'command': 'overlay_gpu 1'})
try:
    for stage in stages:
        native('set_game_object', {'id': TREE, 'enabled': stage != 'off'})
        for _ in range(20):
            time.sleep(1)
            check()
        samples = []
        for _ in range(10):
            camera = check()
            d = diagnostic()
            samples.append({'camera': camera, 'diagnostic': d})
            time.sleep(1)
        result['stages'].append({'stage': stage, 'samples': samples})
        save()
        print(json.dumps({'stage': stage, 'frame': d['frame'], 'camera': camera,
                         'gpu': d['profiler']['gpu'][:5]}), flush=True)
        if stage != 'off':
            capture = call('call_tool', {'name': 'ejected_camera_screenshot', 'arguments': {'width': 1600, 'height': 900, 'fieldOfView': 60}})
            assert not capture.get('isError'), capture
            item = next(c for c in capture['content'] if c['type'] == 'image')
            (OUT / (label + '-' + pose + '-' + stage + '.png')).write_bytes(base64.b64decode(item['data']))
finally:
    native('set_game_object', {'id': TREE, 'enabled': original['Enabled']})
    native('console_command', {'command': 'overlay_gpu 0'})
    result['sourceUnchanged'] = source() == result['source']
    result['restored'] = native('get_game_object', {'id': TREE, 'includeComponentProperties': True})
    save()
