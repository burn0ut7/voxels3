"""Repartition existing Blender FBX leaves without changing any corner payload."""
import copy, hashlib, io, json, math, struct, zlib
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
KEY = 'oak_growth_18_open_grown_271828_dense'
SOURCE = ROOT / 'Assets/models/tree_lab' / KEY
OUT = ROOT / '.codex/tree-scale-048/spatial' / KEY
OUT.mkdir(parents=True, exist_ok=True)
DTYPES = {'f':'<f4', 'd':'<f8', 'i':'<i4', 'l':'<i8', 'b':'u1'}
SCALARS = {'Y':'h', 'C':'?', 'I':'i', 'F':'f', 'D':'d', 'L':'q'}

class Node:
    def __init__(self, name, props, children):
        self.name, self.props, self.children = name, props, children
    def child(self, name):
        return next(c for c in self.children if c.name == name)
    def value(self, name):
        return self.child(name).props[0][1]
    def set(self, name, value):
        n = self.child(name)
        n.props[0] = (n.props[0][0], value)

def read(path):
    f = io.BytesIO(path.read_bytes())
    header = f.read(27)
    assert header[:23] == b'Kaydara FBX Binary  \x00\x1a\x00'
    assert struct.unpack('<I', header[23:])[0] == 7400
    def node():
        end, count, size, nlen = struct.unpack('<IIIB', f.read(13))
        if not end:
            assert count == size == nlen == 0
            return None
        name = f.read(nlen)
        props = []
        for _ in range(count):
            t = f.read(1).decode()
            if t in DTYPES:
                length, encoded, size = struct.unpack('<III', f.read(12))
                data = f.read(size)
                assert encoded in (0, 1)
                value = np.frombuffer(zlib.decompress(data) if encoded else data, dtype=DTYPES[t])
                assert len(value) == length
            elif t in 'SR':
                value = f.read(struct.unpack('<I', f.read(4))[0])
            else:
                fmt = SCALARS[t]
                value = struct.unpack('<' + fmt, f.read(struct.calcsize(fmt)))[0]
            props.append((t, value))
        children = []
        while f.tell() < end:
            child = node()
            if child is not None: children.append(child)
        assert f.tell() == end
        return Node(name.decode(), props, children)
    nodes = []
    while (n := node()) is not None: nodes.append(n)
    return header, nodes, f.read()

def write(path, data):
    header, nodes, footer = data
    f = io.BytesIO()
    f.write(header)
    def node(n):
        start = f.tell()
        name = n.name.encode()
        f.write(b'\0' * 13 + name)
        props_start = f.tell()
        for t, value in n.props:
            f.write(t.encode())
            if t in DTYPES:
                value = np.asarray(value, dtype=DTYPES[t]).ravel()
                compressed = zlib.compress(value.tobytes(), 1)
                f.write(struct.pack('<III', len(value), 1, len(compressed)))
                f.write(compressed)
            elif t in 'SR': f.write(struct.pack('<I', len(value)) + value)
            else: f.write(struct.pack('<' + SCALARS[t], value))
        props_size = f.tell() - props_start
        for c in n.children: node(c)
        if n.children: f.write(b'\0' * 13)
        end = f.tell()
        f.seek(start)
        f.write(struct.pack('<IIIB', end, len(n.props), props_size, len(name)))
        f.seek(end)
    for n in nodes: node(n)
    f.write(b'\0' * 13)
    # Blender's footer starts with a fixed magic and alignment padding. The
    # reader uses node end offsets; preserve footer contents and version.
    f.write(footer)
    path.write_bytes(f.getvalue())

def geometry(data):
    return next(n for n in next(n for n in data[1] if n.name == 'Objects').children if n.name == 'Geometry')

def layers(g):
    return [n for n in g.children if n.name.startswith('LayerElement')]

def layer_array(layer, corners, faces):
    name = layer.name
    payload, index, width = {
        'LayerElementUV': ('UV', 'UVIndex', 2),
        'LayerElementNormal': ('Normals', 'NormalsIndex', 3),
        'LayerElementColor': ('Colors', 'ColorIndex', 4),
        'LayerElementMaterial': ('Materials', None, 1),
        'LayerElementSmoothing': ('Smoothing', None, 1),
    }[name]
    a = layer.value(payload).reshape(-1, width)
    mapping = layer.value('MappingInformationType')
    reference = layer.value('ReferenceInformationType')
    if index and reference == b'IndexToDirect': a = a[layer.value(index)]
    else: assert reference == b'Direct' or name == 'LayerElementMaterial'
    assert mapping in (b'ByPolygon', b'ByPolygonVertex')
    assert len(a) == (faces if mapping == b'ByPolygon' else corners)
    return payload, index, a, mapping

def spatial_groups(centers, count):
    """Balanced, stable median splits. All leaves occur in exactly one group."""
    def split(ids, groups):
        if groups == 1: return [np.sort(ids)]
        axis = int(np.argmax(np.ptp(centers[ids], axis=0)))
        ordered = ids[np.argsort(centers[ids, axis], kind='stable')]
        left = groups // 2
        cut = len(ids) * left // groups
        return split(ordered[:cut], left) + split(ordered[cut:], groups-left)
    result = split(np.arange(len(centers), dtype=np.int32), count)
    assert np.array_equal(np.sort(np.concatenate(result)), np.arange(len(centers)))
    return result

manifest = json.loads((SOURCE / 'manifest.json').read_text())
parts = [m for m in manifest['render_models'] if m['role'] == 'foliage']
assert len(parts) == 4
centers = []
for part in parts:
    g = geometry(read(SOURCE / part['mesh_files'][2]))
    points = g.value('Vertices').reshape(-1, 4, 3).astype(np.float32)
    centers.append(points.mean(axis=1))
groups = spatial_groups(np.concatenate(centers), len(parts))
report = {'method':'spatial_balanced_v1', 'groups':[], 'lods':[]}
for group in groups:
    report['groups'].append({'count':len(group), 'ids_sha256':hashlib.sha256(group.astype('<i4').tobytes()).hexdigest()})

for lod in range(3):
    print('Reading LOD', lod, flush=True)
    inputs = [read(SOURCE / part['mesh_files'][lod]) for part in parts]
    geometries = [geometry(x) for x in inputs]
    verts_per_leaf, faces_per_leaf = [(9,8),(5,4),(4,2)][lod]
    vertices = np.concatenate([g.value('Vertices').reshape(-1,3) for g in geometries])
    polygons = []
    offset = 0
    for g in geometries:
        p = g.value('PolygonVertexIndex').reshape(-1,3)
        assert np.all(p[:,:2] >= 0) and np.all(p[:,2] < 0)
        p = p.copy(); p[:,2] = -p[:,2]-1; polygons.append(p+offset)
        offset += len(g.value('Vertices'))//3
    polygons = np.concatenate(polygons)
    assert len(vertices) == len(np.concatenate(centers))*verts_per_leaf
    assert len(polygons) == len(np.concatenate(centers))*faces_per_leaf
    originals = []
    for number, template in enumerate(layers(geometries[0])):
        payloads = []
        for g in geometries:
            layer = layers(g)[number]
            assert layer.name == template.name and layer.value('Name') == template.value('Name')
            payload, index, a, mapping = layer_array(layer,len(g.value('PolygonVertexIndex')),len(g.value('PolygonVertexIndex'))//3)
            payloads.append(a)
        originals.append((payload,index,np.concatenate(payloads),mapping))
    for index, group in enumerate(groups):
        data = copy.deepcopy(inputs[0])
        g = geometry(data)
        faces = (group[:,None]*faces_per_leaf + np.arange(faces_per_leaf)).ravel()
        corners = (faces[:,None]*3+np.arange(3)).ravel()
        used, remapped = np.unique(polygons[faces].ravel(), return_inverse=True)
        assert len(used) == len(group)*verts_per_leaf
        selected = vertices[used]
        g.set('Vertices',selected.ravel())
        p = remapped.reshape(-1,3).astype('<i4'); p[:,2] = -p[:,2]-1
        g.set('PolygonVertexIndex',p.ravel())
        checks = []
        for layer, (payload, ind, a, mapping) in zip(layers(g),originals):
            selection = faces if mapping == b'ByPolygon' else corners
            value = a[selection]
            layer.set(payload,value.ravel())
            if ind: layer.set(ind,np.arange(len(value),dtype='<i4'))
            checks.append(value)
        path = OUT / parts[index]['mesh_files'][lod]
        write(path,data)
        # Reparse the actual output, checking every triangle/corner payload.
        checked = geometry(read(path))
        cp=checked.value('PolygonVertexIndex').reshape(-1,3).copy();cp[:,2]=-cp[:,2]-1
        assert np.array_equal(checked.value('Vertices').reshape(-1,3)[cp],vertices[polygons[faces]])
        for layer, expected in zip(layers(checked),checks):
            assert np.array_equal(layer_array(layer,len(cp)*3,len(cp))[2],expected)
        report['lods'].append({'lod':lod,'piece':index,'vertices':len(selected),'triangles':len(faces),
            'bounds_inches':[selected.min(0).tolist(),selected.max(0).tolist()],
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,
            'all_triangles_and_corner_payloads_exact':True})
        print('Verified',path.name,len(group),'leaves',flush=True)
    del inputs, geometries, originals, polygons, vertices, data, g, checked
(OUT / 'repartition-report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('Complete; no watched asset was changed.',flush=True)
