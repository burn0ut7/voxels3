import sys,json,base64,math,time
from pathlib import Path
sys.path.insert(0,str(Path('.codex/cloud-build').resolve()))
from native import native,call
OUT=Path('Docs/ValidationEvidence/TreeScale048');TREE='8ecd0810-19a7-4b29-be95-792f0de4145f';CENTER=(-1779.083351,-1792.61467,362.14073)
label=sys.argv[1]; records=[]; last=None
def shot(a,d,reference=False):
 global last
 if last is not None:
  c=native('get_ejected_camera')
  assert math.dist(last,list(map(float,c['Position'].split(',')))) < .02,'Camera changed; stopping'
 e=math.radians(15);r=math.radians(a);p=(CENTER[0]+d*math.cos(e)*math.cos(r),CENTER[1]+d*math.cos(e)*math.sin(r),CENTER[2]+d*math.sin(e))
 native('set_ejected_camera',{'position':','.join(map(str,p)),'angles':f'15,{a-180},0','fieldOfView':75})
 last=p
 props={'DetailReturnMeters':10000,'DetailExitMeters':10001} if reference else {'DetailReturnMeters':12,'DetailExitMeters':16}
 native('set_component',{'id':TREE,'type':'TreeModelLod','properties':props});time.sleep(.6)
 obj=native('get_game_object',{'id':TREE,'includeComponentProperties':True});lod=next(c['Properties'] for c in obj['Components'] if c['Type']=='TreeModelLod');assert all(lod[k]==v for k,v in props.items())
 result=call('call_tool',{'name':'ejected_camera_screenshot','arguments':{'width':1600,'height':900,'fieldOfView':75}})
 name=f'{label}-{a}-{d}-'+('mesh' if reference else 'far')
 for item in result['content']:
  if item['type']=='image':(OUT/(name+'.png')).write_bytes(base64.b64decode(item['data']))
 records.append({'name':name,'camera':native('get_ejected_camera'),'lod':lod});print(name,lod['Status'],flush=True)
native('set_editor_camera_ejected',{'ejected':True})
try:
 for a in [180,203,225,315]:shot(a,700)
finally:
 native('set_component',{'id':TREE,'type':'TreeModelLod','properties':{'DetailReturnMeters':12,'DetailExitMeters':16}})
 # Keep the fixed viewport for the next matching capture.
 native('set_ejected_camera',{'position':'-2500,-2500,470','angles':'6.3,45,0','fieldOfView':60})
 (OUT/(label+'-visual.json')).write_text(json.dumps(records,indent=2))
