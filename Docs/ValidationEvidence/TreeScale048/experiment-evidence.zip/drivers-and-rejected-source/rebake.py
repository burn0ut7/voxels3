import json,sys
from pathlib import Path
sys.path.insert(0,'.codex/cloud-build')
from native import native
for row in range(4):
 r=native('bake_tree_impostor',{'specimen':'oak_growth_18_open_grown_271828_dense','elevationRow':row})
 Path(f'Docs/ValidationEvidence/TreeScale048/candidate-f-bake-{row}.json').write_text(json.dumps(r,indent=2))
 print('Baked row',row,flush=True)
