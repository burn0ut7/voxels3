import sys,json,base64,math,time
from pathlib import Path
sys.path.insert(0,str(Path('.codex/cloud-build').resolve()))
from native import native,call
OUT=Path('Docs/ValidationEvidence/TreeScale048')
TREE='8ecd0810-19a7-4b29-be95-792f0de4145f'
CENTER=(-1779.083351,-1792.61467,362.14073)
label=sys.argv[1];frames=[];last=None
native('set_editor_camera_ejected',{'ejected':True})
objects=[]
try:
 for obj in objects:
  if obj['Id']!=TREE and obj['Enabled']:native('set_game_object',{'id':obj['Id'],'enabled':False})
 native('set_component',{'id':TREE,'type':'TreeModelLod','properties':{'DetailReturnMeters':12,'DetailExitMeters':16}})
 for leg,distances in [('retreat',range(450,811,10)),('approach',range(810,449,-10))]:
  for distance in distances:
   if last is not None:
    current=list(map(float,native('get_ejected_camera')['Position'].split(',')))
    if math.dist(last,current)>2:raise RuntimeError('Camera was moved externally; stopped the capture path')
   position=(CENTER[0]-distance,CENTER[1],250.125)
   pitch=math.degrees(math.atan2(position[2]-CENTER[2],distance))
   native('set_ejected_camera',{'position':','.join(map(str,position)),'angles':f'{pitch},0,0','fieldOfView':75})
   if last is None:time.sleep(.6)
   last=position
   obj=native('get_game_object',{'id':TREE,'includeComponentProperties':True})
   lod=next(c['Properties'] for c in obj['Components'] if c['Type']=='TreeModelLod')
   assert lod['DetailReturnMeters']==12 and lod['DetailExitMeters']==16,lod
   result=call('call_tool',{'name':'ejected_camera_screenshot','arguments':{'width':1280,'height':720,'fieldOfView':75}})
   name=f'{label}-{leg}-{distance}'
   for item in result['content']:
    if item['type']=='image':(OUT/(name+'.png')).write_bytes(base64.b64decode(item['data']))
   frames.append({'name':name,'utc':time.time(),'position':position,'lod':lod})
   print(leg,distance,lod['Status'],lod['DetailFraction'],flush=True)
finally:
 for obj in objects:
  if obj['Id']!=TREE:native('set_game_object',{'id':obj['Id'],'enabled':obj['Enabled']})
 (OUT/(label+'.json')).write_text(json.dumps(frames,indent=2))
