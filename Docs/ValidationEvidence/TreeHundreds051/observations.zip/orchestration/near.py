import base64,datetime,json,re,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'.codex/tree-performance'))
from measure import native,call,diagnostic,source
OUT=ROOT/'Docs/ValidationEvidence/TreeHundreds051'
KEY='oak_growth_18_open_grown_271828_dense'
TREE='8ecd0810-19a7-4b29-be95-792f0de4145f'
position='-6200,-6200,3600';angles='20,45,0'
label=sys.argv[1];keep='--keep' in sys.argv;near='--near' in sys.argv;counts=[int(n) for n in sys.argv[2:] if not n.startswith('--')] or [1,64,256,1024]
placements=json.loads((ROOT/'Docs/ValidationEvidence/TreeScale048/placements-v1.json').read_text())
path=OUT/(label+'-forest.json')
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source(),'stages':[],'created':[]}
initial_player=diagnostic()['playerPosition']
completed=False
def save():path.write_text(json.dumps(result,indent=2),encoding='utf-8')
def check():
 c=native('get_ejected_camera')
 assert all(abs(float(a)-float(b))<.02 for key,value in [('Position',position),('Angles',angles)] for a,b in zip(c[key].split(','),value.split(','))), 'Camera moved; stopping'
 assert abs(c['RenderWidth']-2769)<1 and abs(c['RenderHeight']-1528.5)<1,c
 return c
native('set_editor_camera_ejected',{'ejected':True})
native('set_ejected_camera',{'position':position,'angles':angles,'fieldOfView':60})
native('set_game_render_resolution',{'width':1846,'height':1019})
assert native('find_game_objects',{'name':'Hundreds051 Forest','limit':1})['Total']==0
parent=native('create_game_object',{'name':'Hundreds051 Forest','position':'0,0,0'})['Id']
result['parent']=parent;save()
native('console_command',{'command':'overlay_gpu 1'})
try:
 for count in counts:
  position='-6200,-6200,3600';angles='20,45,0'
  native('set_ejected_camera',{'position':position,'angles':angles,'fieldOfView':60})
  for begin in range(len(result['created'])+1,count,16):
   check()
   batch=placements[begin:min(begin+16,count)]
   for attempt in range(3):
    missing=batch[len(result['created'])-(begin-1):]
    response=call('call_tools',{'calls':[{'Name':'create_game_object','Arguments':{'name':f"Hundreds051 Oak {r['i']} {r['j']}",'parent':parent,'prefab':f'models/tree_lab/{KEY}/{KEY}.prefab','position':r['position'],'angles':'0,0,0','scale':'1'}} for r in missing]})
    for item in response.get('content',[]):
     if item['type']=='text':
      try: created=json.loads(item['text'])
      except ValueError: continue
      if isinstance(created,dict) and 'Id' in created:result['created'].append(created['Id'])
    save()
    if len(result['created'])==min(begin+16,count)-1:break
    assert any("Couldn't instantiate prefab" in x.get('text','') for x in response.get('content',[])),response
    children=native('get_game_object',{'id':parent})['Children']
    assert {c['Id'] for c in children}==set(result['created']), 'Unexpected partial creation; no retry'
    result.setdefault('creationRetries',[]).append({'at':len(result['created']),'attempt':attempt,'response':response})
    save();time.sleep(.1);check()
   assert len(result['created'])==min(begin+16,count)-1,response
   print('Created',len(result['created']),flush=True)
  poses=[('near','-2110,-2110,350','-8,45,0'),('close','-1864,-1864,250.125','-35,45,0')] if near else [('wide',position,angles)]
  for pose,position,angles in poses:
   native('set_ejected_camera',{'position':position,'angles':angles,'fieldOfView':60})
   for _ in range(20):time.sleep(1);check()
   samples=[]
   for _ in range(10):
    c=check();d=diagnostic();samples.append({'camera':c,'diagnostic':d})
    assert float(d['frame'].split()[0])>=30,'Below safety frame rate; stopping'
    assert all(abs(float(a)-float(b))<.05 for a,b in zip(d['playerPosition'].split(','),initial_player.split(','))), 'Player moved; stopping'
    time.sleep(1)
   trees=native('find_game_objects',{'component':'TreeModelLod','limit':500})
   stage={'count':count,'pose':pose,'treeObjects':trees,'samples':samples}
   result['stages'].append(stage);save()
   print(json.dumps({'count':count,'pose':pose,'actualTrees':trees['Total'],'frame':d['frame'],'counters':c['Frame']}),flush=True)
   capture=call('call_tool',{'name':'ejected_camera_screenshot','arguments':{'width':1600,'height':900,'fieldOfView':60}})
   assert not capture.get('isError'),capture
   img=next(c for c in capture['content'] if c['type']=='image')
   (OUT/f'{label}-forest-{count}-{pose}.png').write_bytes(base64.b64decode(img['data']))
   # Inspect normal production LOD state outside the timed observation window.
   states=[];ids=[TREE]+result['created']
   for begin in range(0,len(ids),16):
    check()
    response=call('call_tools',{'calls':[{'Name':'get_game_object','Arguments':{'id':i,'includeComponentProperties':True}} for i in ids[begin:begin+16]]})
    for item in response.get('content',[]):
     if item['type']!='text':continue
     obj=json.loads(item['text'])
     component=next(c for c in obj['Components'] if c['Type']=='TreeModelLod')
     props=component['Properties']
     states.append({'id':obj['Id'],'position':obj['WorldPosition'],'status':props['Status'],'detailFraction':props['DetailFraction'],'distanceMeters':props['ViewDistanceMeters']})
   assert len(states)==count,(len(states),count)
   stage['lodStates']=states;save()
 completed=True

finally:
 if not (completed and keep):native('delete_game_object',{'id':parent})
 native('console_command',{'command':'overlay_gpu 0'})
 result['retained']=completed and keep;result['sourceUnchanged']=source()==result['source'];result['remainingTrees']=native('find_game_objects',{'component':'TreeModelLod','limit':2});save()
