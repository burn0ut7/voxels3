import base64, datetime, gzip, hashlib, json, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / '.codex/cloud-build'))
from native import native, call
sys.path.insert(0, str(ROOT / '.codex/tree-performance'))
from measure import diagnostic, source, compact

OUT = ROOT / 'Docs/ValidationEvidence/TreeHundreds051'
TREE = '8ecd0810-19a7-4b29-be95-792f0de4145f'
LABEL = sys.argv[2]
TASK = 'TREE-HUNDREDS-051/control-v1'

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2), encoding='utf-8')

def tree():
    obj = native('get_game_object', {'id': TREE, 'includeComponentProperties': True})
    assert obj['Name'] == 'Sprite Leaf Test Oak' and obj['Enabled']
    return obj

def capture(name):
    result = call('call_tool', {'name': 'ejected_camera_screenshot', 'arguments': {'width': 1600, 'height': 900, 'fieldOfView': 60}})
    if result.get('isError'): raise RuntimeError(result)
    img = next(c for c in result['content'] if c['type'] == 'image')
    (OUT / (name + '.png')).write_bytes(base64.b64decode(img['data']))

mode = sys.argv[1]
if mode == 'visual' and len(sys.argv) > 2:
    LABEL += '-' + sys.argv[2]
if mode == 'visual':
    tree()
    native('set_editor_camera_ejected', {'ejected': True})
    native('set_ejected_camera', {'position': '-2500,-2500,470', 'angles': '6.3,45,0', 'fieldOfView': 60})
    time.sleep(2)
    capture(LABEL + '-full')
    full = {'camera': native('get_ejected_camera'), 'tree': tree()}
    native('set_ejected_camera', {'position': '-1864,-1864,250.125', 'angles': '-35,45,0', 'fieldOfView': 60})
    time.sleep(2)
    frames = []
    for i in range(6):
        capture(LABEL + '-wind-' + str(i))
        frames.append(native('get_ejected_camera'))
        time.sleep(.25)
    close = tree()
    children = [native('get_game_object', {'id': c['Id'], 'includeComponentProperties': True}) for c in close['Children']]
    save(LABEL + '-visual.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'full': full, 'close': close, 'children': children, 'frames': frames, 'source': source()})
    native('set_ejected_camera', {'position': '-2500,-2500,470', 'angles': '6.3,45,0', 'fieldOfView': 60})
    print('Visual evidence saved.')
elif mode == 'run':
    assert not native('get_game_object', {'id': '5661de64-ff14-40b0-adb2-aca29d3895bd'})['ActiveInHierarchy'], 'Control requires disabled temporary forest'
    assert native('find_game_objects', {'component': 'TreeModelLod', 'limit': 1})['Total'] == 512, 'Expected the declared512-tree population'
    tree()
    native('set_component', {'id': 'd3b30a99-ed5a-42e2-9229-3888b6c1f191', 'type': 'VoxelManager', 'properties': {'GrassRenderRangeMeters': 64}})
    native('set_editor_camera_ejected', {'ejected': False})
    native('set_player_view', {'angles': '0,0,0'})
    native('set_game_render_resolution', {'width': 1846, 'height': 1019})
    native('set_game_object', {'id': 'fde76e17-1db9-4ccc-a193-897fddbc6239', 'position': '-1.6258175,1.2225341,340'})
    for attempt in range(60):
        d = diagnostic()
        ready = d['visualPending'] == d['transitionPending'] == 0 and not d['placementPending'] and d['waterCellsReady'] and d['collision']['ready'] == 4913 and d['collision']['pending'] == 0 and not d['collision']['building'] and d['heldBodies'] == 0
        if attempt % 4 == 0 or ready: print(json.dumps({'attempt': attempt, 'ready': ready, **compact(d)}), flush=True)
        if ready: break
        time.sleep(5)
    assert ready, 'Streaming did not settle; no run started'
    assert (d['profiler']['screenWidth'], d['profiler']['screenHeight']) == (2769, 1529)
    tree_state = tree()
    tree_lod = next(c['Properties'] for c in tree_state['Components'] if c['Type'] == 'TreeModelLod')
    assert tree_lod['Status'] == 'Distant' and tree_lod['DetailFraction'] == 0, tree_lod
    hashes = source()
    save(LABEL + '-before.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source': hashes, 'diagnostic': d, 'editor': native('editor_status'), 'tree': tree_state})
    result = call('call_tools', {'calls': [
        {'Name': 'set_game_object', 'Arguments': {'id': 'fde76e17-1db9-4ccc-a193-897fddbc6239', 'position': '-1.6258175,1.2225341,340'}},
        {'Name': 'run_performance_test', 'Arguments': {'task': TASK, 'revision': hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest(), 'speed': 2500, 'distance': 50000, 'loopCount': 1}}]})
    assert not result.get('isError'), result
    assert any('Performance test test started' in x.get('text', '') for x in result.get('content', [])), result
    save(LABEL + '-trigger.json', result)
    print('TRIGGER', result, flush=True)
elif mode == 'result':
    p = Path('C:/Program Files (x86)/Steam/steamapps/common/sbox/data/local/voxels3#local/performance/results-v1.jsonl')
    with p.open('rb') as f:
        f.seek(0,2); pos = f.tell(); tail = b''
        while pos:
            n = min(pos,1048576); pos -= n; f.seek(pos); tail = f.read(n) + tail
            lines = tail.rstrip(b'\r\n').split(b'\n')
            if len(lines) > 1 or pos == 0: raw = lines[-1]; break
    data = json.loads(raw)
    assert data['source']['task'] == TASK, data['source']
    expected = json.loads((OUT / (LABEL + '-before.json')).read_text(encoding='utf-8'))['source']
    assert data['source']['revision'] == hashlib.sha256(json.dumps(expected, sort_keys=True).encode()).hexdigest(), 'Latest result belongs to a different source; requested run has not finished'
    with gzip.open(OUT / (LABEL + '.json.gz'), 'wb') as f: f.write(raw)
    summary = {k: data.get(k) for k in ['runId','source','outcome','test','world','frame','memory','runtime','collision','lodArrivalStatus']}
    summary['stationary'] = {k: data['stationary'].get(k) for k in ['frame','memory','runtime','collision','profiler']}
    summary['sourceUnchanged'] = json.loads((OUT / (LABEL + '-before.json')).read_text(encoding='utf-8'))['source'] == source()
    save(LABEL + '-summary.json', summary)
    print(json.dumps({k: summary[k] for k in ['runId','outcome','frame','sourceUnchanged']}))
    print('Standing', summary['stationary']['frame'])

