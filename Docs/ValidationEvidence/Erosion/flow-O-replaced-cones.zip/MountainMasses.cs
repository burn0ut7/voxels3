using System;

/// <summary>Seeded mountain groups with shared foundations, summits, slopes and bounds.</summary>
internal static class MountainMasses
{
	// Group spacing is independent of mountain-region coverage (MountainAmount).
	private const float GroupSpacing = 1.6f;
	private const float TipSquared = 0.0004f;
	private const float OuterRadius = 1.00019998f;
	private const float ConeSpan = 0.98019998f;
	private readonly record struct Group( Vector2 Center, Vector2 Axis, float Major, float Minor, float Height, float Foundation, uint Layout );
	private readonly record struct Peak( Vector2 Center, float Major, float Minor, float Height );

	private static Group At( int x, int y, uint seed )
	{
		var a = TerrainNoise.Hash( x, y, seed ^ 0x7F4A7C15u );
		var b = TerrainNoise.Hash( x, y, seed ^ 0x94D049BBu );
		if ( (b >> 24) < 24u )
		{
			return default;
		}
		var axisX = (b & 255u) - 127.5f;
		var axisY = ((b >> 8) & 255u) - 127.5f;
		var axisLength = MathF.Sqrt( axisX * axisX + axisY * axisY );
		var height = ((a >> 16) & 255u) / 255f;
		return new Group(
			new Vector2( x + 0.5f + ((a & 255u) / 255f - 0.5f) * 0.36f,
				y + 0.5f + (((a >> 8) & 255u) / 255f - 0.5f) * 0.36f ),
			new Vector2( axisX / axisLength, axisY / axisLength ),
			0.60f + 0.55f * ((a >> 24) & 255u) / 255f,
			0.40f + 0.45f * ((b >> 16) & 255u) / 255f,
			0.65f + 0.35f * height, ((b >> 22) & 3u) == 1u ? 0.50f : ((b >> 22) & 3u) == 3u ? 0.35f : 0.20f, b );
	}

	private static Peak Summit( uint layout, int index )
	{
		var a = (layout & 255u) / 255f;
		var b = ((layout >> 8) & 255u) / 255f;
		var kind = (layout >> 22) & 3u;
		if ( kind == 0u )
		{
			if ( index == 0 )
			{
				return new Peak( new Vector2( (a - 0.5f) * 0.12f, (b - 0.5f) * 0.12f ), 0.42f + 0.10f * a, 0.42f + 0.10f * b, 1.0f );
			}
			if ( index == 1 )
			{
				return new Peak( new Vector2( -0.35f, 0.12f ), 0.35f, 0.38f, 0.30f + 0.20f * a );
			}
			return new Peak( new Vector2( 0.30f, -0.18f ), 0.32f, 0.34f, 0.20f + 0.20f * b );
		}
		if ( kind == 1u )
		{
			if ( index == 0 )
			{
				return new Peak( new Vector2( 0.0f, 0.0f ), 0.70f, 0.65f, 0.92f );
			}
			if ( index == 1 )
			{
				return new Peak( new Vector2( -0.22f, 0.18f ), 0.50f, 0.50f, 0.65f );
			}
			return new Peak( new Vector2( 0.28f, -0.15f ), 0.48f, 0.48f, 0.50f );
		}
		if ( kind == 2u )
		{
			if ( index == 0 )
			{
				return new Peak( new Vector2( -0.24f, -0.10f ), 0.42f, 0.47f, 0.80f + 0.15f * a );
			}
			if ( index == 1 )
			{
				return new Peak( new Vector2( 0.25f, 0.12f ), 0.43f, 0.45f, 1.0f );
			}
			return new Peak( new Vector2( -0.05f, 0.38f ), 0.30f, 0.32f, 0.45f + 0.15f * b );
		}
		{
			if ( index == 0 )
			{
				return new Peak( new Vector2( 0.0f, 0.0f ), 0.76f, 0.30f, 0.92f );
			}
			if ( index == 1 )
			{
				return new Peak( new Vector2( -0.40f, 0.14f ), 0.39f, 0.30f, 0.65f + 0.25f * a );
			}
			return new Peak( new Vector2( 0.38f, -0.13f ), 0.38f, 0.29f, 0.60f + 0.25f * b );
		}
	}

	private static float SamplePeak( Vector2 point, Peak peak, out Vector2 gradient, out float peakFraction )
	{
		var u = (point.x - peak.Center.x) / peak.Major;
		var v = (point.y - peak.Center.y) / peak.Minor;
		var radiusSquared = u * u + v * v;
		gradient = default;
		peakFraction = 0f;
		if ( radiusSquared >= 1f )
		{
			return 0f;
		}
		var radius = MathF.Sqrt( radiusSquared + TipSquared );
		var cone = Math.Clamp( (OuterRadius - radius) / ConeSpan, 0f, 1f );
		gradient = new Vector2( u / peak.Major, v / peak.Minor ) *
			(-2f * peak.Height * cone / (radius * ConeSpan));
		peakFraction = cone * cone;
		return peak.Height * peakFraction;
	}

	public static float Sample( Vector3 position, float scale, uint seed, out Vector2 gradient, out float peakFraction, out float erosionStrength )
	{
		scale *= GroupSpacing;
		var point = new Vector2( position.x / scale, position.y / scale );
		var cellX = (int)MathF.Floor( point.x );
		var cellY = (int)MathF.Floor( point.y );
		var mass = 0f;
		gradient = default;
		peakFraction = 0f;
		erosionStrength = 0f;
		// All subsidiary peaks fit inside the group's ellipse. Support <=1.15,
		// jitter <=.18 and omitted-cell distance >=1.32 still justify nine cells.
		for ( var y = -1; y <= 1; y++ )
		{
			for ( var x = -1; x <= 1; x++ )
			{
				var group = At( cellX + x, cellY + y, seed );
				if ( group.Height <= 0f )
				{
					continue;
				}
				var delta = point - group.Center;
				var u = (delta.x * group.Axis.x + delta.y * group.Axis.y) / group.Major;
				var v = (-delta.x * group.Axis.y + delta.y * group.Axis.x) / group.Minor;
				var radiusSquared = u * u + v * v;
				if ( radiusSquared >= 1f )
				{
					continue;
				}
				var foundation = 1f - radiusSquared;
				var summits = 0f;
				var summitGradient = Vector2.Zero;
				for ( var i = 0; i < 3; i++ )
				{
					var peak = Summit( group.Layout, i );
					var height = SamplePeak( new Vector2( u, v ), peak, out var peakGradient, out var localPeakFraction );
					peakFraction = MathF.Max( peakFraction, localPeakFraction * group.Height * peak.Height );
					summitGradient = summitGradient * (1f - height) + peakGradient * (1f - summits);
					summits += (1f - summits) * height;
				}
				erosionStrength = MathF.Max( erosionStrength, foundation * foundation * (0.15f + 0.85f * (group.Layout >> 24) / 255f) );
				var groupHeight = group.Height * (group.Foundation * foundation * foundation + (1f - group.Foundation) * summits);
				var localGradient = (new Vector2( u, v ) * (-4f * group.Foundation * foundation) + (1f - group.Foundation) * summitGradient) * group.Height;
				var groupGradient = new Vector2(
					localGradient.x * group.Axis.x / group.Major - localGradient.y * group.Axis.y / group.Minor,
					localGradient.x * group.Axis.y / group.Major + localGradient.y * group.Axis.x / group.Minor ) / scale;
				gradient = gradient * (1f - groupHeight) + groupGradient * (1f - mass);
				mass += (1f - mass) * groupHeight;
			}
		}
		return mass;
	}

	private static (double Minimum, double Maximum) RadiusBounds( double u, double v, double ru, double rv, Peak peak )
	{
		u = Math.Abs( (u - peak.Center.x) / peak.Major );
		v = Math.Abs( (v - peak.Center.y) / peak.Minor );
		ru /= peak.Major;
		rv /= peak.Minor;
		var nearU = Math.Max( 0d, u - ru );
		var nearV = Math.Max( 0d, v - rv );
		var farU = u + ru;
		var farV = v + rv;
		return (nearU * nearU + nearV * nearV, farU * farU + farV * farV);
	}

	public static (double Minimum, double Maximum) Bound( SdfWorldAabb bounds, float scale, uint seed )
	{
		scale *= GroupSpacing;
		var minX = (double)bounds.Minimum.x / scale;
		var minY = (double)bounds.Minimum.y / scale;
		var maxX = (double)bounds.Maximum.x / scale;
		var maxY = (double)bounds.Maximum.y / scale;
		var padding = 0.0001d + Math.Max( Math.Max( Math.Abs( minX ), Math.Abs( maxX ) ),
			Math.Max( Math.Abs( minY ), Math.Abs( maxY ) ) ) * 0.000001d;
		minX -= padding;
		minY -= padding;
		maxX += padding;
		maxY += padding;
		var cellX = (int)Math.Floor( minX );
		var cellY = (int)Math.Floor( minY );
		if ( cellX != (int)Math.Floor( maxX ) || cellY != (int)Math.Floor( maxY ) )
		{
			return (0d, 1d);
		}
		var centerX = (minX + maxX) * 0.5d;
		var centerY = (minY + maxY) * 0.5d;
		var halfX = (maxX - minX) * 0.5d;
		var halfY = (maxY - minY) * 0.5d;
		var emptyMinimum = 1d;
		var emptyMaximum = 1d;
		for ( var y = -1; y <= 1; y++ )
		{
			for ( var x = -1; x <= 1; x++ )
			{
				var group = At( cellX + x, cellY + y, seed );
				if ( group.Height <= 0f )
				{
					continue;
				}
				var dx = centerX - group.Center.x;
				var dy = centerY - group.Center.y;
				var u = (dx * group.Axis.x + dy * group.Axis.y) / group.Major;
				var v = (-dx * group.Axis.y + dy * group.Axis.x) / group.Minor;
				var ru = (halfX * Math.Abs( group.Axis.x ) + halfY * Math.Abs( group.Axis.y )) / group.Major;
				var rv = (halfX * Math.Abs( group.Axis.y ) + halfY * Math.Abs( group.Axis.x )) / group.Minor;
				var foundationRadius = RadiusBounds( u, v, ru, rv, new Peak( default, 1f, 1f, 1f ) );
				if ( foundationRadius.Minimum >= 1d )
				{
					continue;
				}
				var foundationMinimum = Math.Max( 0d, 1d - foundationRadius.Maximum );
				var foundationMaximum = Math.Max( 0d, 1d - foundationRadius.Minimum );
				var summitEmptyMinimum = 1d;
				var summitEmptyMaximum = 1d;
				for ( var i = 0; i < 3; i++ )
				{
					var peak = Summit( group.Layout, i );
					var radius = RadiusBounds( u, v, ru, rv, peak );
					if ( radius.Minimum >= 1d )
					{
						continue;
					}
					var coneMinimum = Math.Clamp( (OuterRadius - Math.Sqrt( radius.Maximum + TipSquared )) / ConeSpan, 0d, 1d );
					var coneMaximum = Math.Clamp( (OuterRadius - Math.Sqrt( radius.Minimum + TipSquared )) / ConeSpan, 0d, 1d );
					summitEmptyMinimum *= 1d - peak.Height * coneMaximum * coneMaximum;
					summitEmptyMaximum *= 1d - peak.Height * coneMinimum * coneMinimum;
				}
				var groupMinimum = group.Height * (group.Foundation * foundationMinimum * foundationMinimum + (1d - group.Foundation) * (1d - summitEmptyMaximum));
				var groupMaximum = group.Height * (group.Foundation * foundationMaximum * foundationMaximum + (1d - group.Foundation) * (1d - summitEmptyMinimum));
				emptyMinimum *= 1d - groupMaximum;
				emptyMaximum *= 1d - groupMinimum;
			}
		}
		return (1d - emptyMaximum, 1d - emptyMinimum);
	}
}
