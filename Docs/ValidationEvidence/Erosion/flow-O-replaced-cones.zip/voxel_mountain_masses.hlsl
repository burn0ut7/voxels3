// GPU mirror of MountainMasses; group geometry, salts and scales are owned there.
struct VoxelMassPeak
{
	float2 Center;
	float Major;
	float Minor;
	float Height;
};

VoxelMassPeak VoxelMassSummit( uint layout, int index )
{
	float a = (layout & 255u) / 255.0;
	float b = ((layout >> 8) & 255u) / 255.0;
	uint kind = (layout >> 22) & 3u;
	VoxelMassPeak peak;
	if ( kind == 0u )
	{
		if ( index == 0 )
		{
			peak.Center = float2( (a - 0.5) * 0.12, (b - 0.5) * 0.12 );
			peak.Major = 0.42 + 0.10 * a;
			peak.Minor = 0.42 + 0.10 * b;
			peak.Height = 1.0;
		}
		else if ( index == 1 )
		{
			peak.Center = float2( -0.35, 0.12 );
			peak.Major = 0.35;
			peak.Minor = 0.38;
			peak.Height = 0.30 + 0.20 * a;
		}
		else
		{
			peak.Center = float2( 0.30, -0.18 );
			peak.Major = 0.32;
			peak.Minor = 0.34;
			peak.Height = 0.20 + 0.20 * b;
		}
	}
	else if ( kind == 1u )
	{
		if ( index == 0 )
		{
			peak.Center = float2( 0.0, 0.0 );
			peak.Major = 0.70;
			peak.Minor = 0.65;
			peak.Height = 0.92;
		}
		else if ( index == 1 )
		{
			peak.Center = float2( -0.22, 0.18 );
			peak.Major = 0.50;
			peak.Minor = 0.50;
			peak.Height = 0.65;
		}
		else
		{
			peak.Center = float2( 0.28, -0.15 );
			peak.Major = 0.48;
			peak.Minor = 0.48;
			peak.Height = 0.50;
		}
	}
	else if ( kind == 2u )
	{
		if ( index == 0 )
		{
			peak.Center = float2( -0.24, -0.10 );
			peak.Major = 0.42;
			peak.Minor = 0.47;
			peak.Height = 0.80 + 0.15 * a;
		}
		else if ( index == 1 )
		{
			peak.Center = float2( 0.25, 0.12 );
			peak.Major = 0.43;
			peak.Minor = 0.45;
			peak.Height = 1.0;
		}
		else
		{
			peak.Center = float2( -0.05, 0.38 );
			peak.Major = 0.30;
			peak.Minor = 0.32;
			peak.Height = 0.45 + 0.15 * b;
		}
	}
	else
	{
		if ( index == 0 )
		{
			peak.Center = float2( 0.0, 0.0 );
			peak.Major = 0.76;
			peak.Minor = 0.30;
			peak.Height = 0.92;
		}
		else if ( index == 1 )
		{
			peak.Center = float2( -0.40, 0.14 );
			peak.Major = 0.39;
			peak.Minor = 0.30;
			peak.Height = 0.65 + 0.25 * a;
		}
		else
		{
			peak.Center = float2( 0.38, -0.13 );
			peak.Major = 0.38;
			peak.Minor = 0.29;
			peak.Height = 0.60 + 0.25 * b;
		}
	}
	return peak;
}

float SampleVoxelMassPeak( float2 point, VoxelMassPeak peak, out float2 gradient, out float peakFraction )
{
	float u = (point.x - peak.Center.x) / peak.Major;
	float v = (point.y - peak.Center.y) / peak.Minor;
	float radiusSquared = u * u + v * v;
	gradient = float2( 0.0, 0.0 );
	peakFraction = 0.0;
	[branch]
	if ( radiusSquared >= 1.0 )
	{
		return 0.0;
	}
	float radius = sqrt( radiusSquared + 0.0004 );
	float cone = clamp( (1.00019998 - radius) / 0.98019998, 0.0, 1.0 );
	gradient = float2( u / peak.Major, v / peak.Minor ) * (-2.0 * peak.Height * cone / (radius * 0.98019998));
	peakFraction = cone * cone;
	return peak.Height * peakFraction;
}

float SampleVoxelMountainMass( float2 position, float scale, uint seed, out float2 gradient, out float peakFraction, out float erosionStrength )
{
	scale *= 1.6;
	float2 point = position / scale;
	int2 origin = (int2)floor( point );
	float mass = 0.0;
	gradient = float2( 0.0, 0.0 );
	peakFraction = 0.0;
	erosionStrength = 0.0;
	[unroll]
	for ( int y = -1; y <= 1; y++ )
	{
		[unroll]
		for ( int x = -1; x <= 1; x++ )
		{
			int2 cell = origin + int2( x, y );
			uint a = VoxelHash2D( cell.x, cell.y, seed ^ 0x7F4A7C15u );
			uint b = VoxelHash2D( cell.x, cell.y, seed ^ 0x94D049BBu );
			[branch]
			if ( (b >> 24) >= 24u )
			{
				float2 axis = float2( (b & 255u) - 127.5, ((b >> 8) & 255u) - 127.5 );
				axis /= sqrt( dot( axis, axis ) );
				float2 center = (float2)cell + 0.5 + (float2( a & 255u, (a >> 8) & 255u ) / 255.0 - 0.5) * 0.36;
				float major = 0.60 + 0.55 * ((a >> 24) & 255u) / 255.0;
				float minor = 0.40 + 0.45 * ((b >> 16) & 255u) / 255.0;
				float height = ((a >> 16) & 255u) / 255.0;
				uint kind = (b >> 22) & 3u;
				float foundationWeight = kind == 1u ? 0.50 : kind == 3u ? 0.35 : 0.20;
				float groupHeightFactor = 0.65 + 0.35 * height;
				float2 delta = point - center;
				float u = (delta.x * axis.x + delta.y * axis.y) / major;
				float v = (-delta.x * axis.y + delta.y * axis.x) / minor;
				float radiusSquared = u * u + v * v;
				[branch]
				if ( radiusSquared < 1.0 )
				{
					float foundation = 1.0 - radiusSquared;
					float summits = 0.0;
					float2 summitGradient = float2( 0.0, 0.0 );
					[unroll]
					for ( int i = 0; i < 3; i++ )
					{
						float2 peakGradient;
						float localPeakFraction;
						VoxelMassPeak peak = VoxelMassSummit( b, i );
						float peakHeight = SampleVoxelMassPeak( float2( u, v ), peak, peakGradient, localPeakFraction );
						peakFraction = max( peakFraction, localPeakFraction * groupHeightFactor * peak.Height );
						summitGradient = summitGradient * (1.0 - peakHeight) + peakGradient * (1.0 - summits);
						summits += (1.0 - summits) * peakHeight;
					}
					erosionStrength = max( erosionStrength, foundation * foundation * (0.15 + 0.85 * (b >> 24) / 255.0) );
					float groupHeight = groupHeightFactor * (foundationWeight * foundation * foundation + (1.0 - foundationWeight) * summits);
					float2 localGradient = (float2( u, v ) * (-4.0 * foundationWeight * foundation) + (1.0 - foundationWeight) * summitGradient) * groupHeightFactor;
					float2 groupGradient = float2( localGradient.x * axis.x / major - localGradient.y * axis.y / minor,
						localGradient.x * axis.y / major + localGradient.y * axis.x / minor ) / scale;
					gradient = gradient * (1.0 - groupHeight) + groupGradient * (1.0 - mass);
					mass += (1.0 - mass) * groupHeight;
				}
			}
		}
	}
	return mass;
}
