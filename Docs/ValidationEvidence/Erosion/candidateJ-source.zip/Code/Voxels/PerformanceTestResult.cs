using System;

internal sealed class PerformanceTestResult
{
	public int SchemaVersion { get; init; }
	public PerformanceCollisionMetrics Collision { get; init; }
	public long CollisionHoldSteps { get; init; }
	public string RunId { get; init; }
	public string CapturedAtUtc { get; init; }
	public string Outcome { get; init; }
	public PerformanceTestSource Source { get; init; }
	public PerformanceTestDefinition Test { get; init; }
	public PerformanceWorldContext World { get; init; }
	public PerformanceFrameMetrics Frame { get; init; }
	public PerformanceRuntimeMetrics Runtime { get; init; }
	public PerformanceStationaryMetrics Stationary { get; init; }
	public PerformanceMemoryMetrics Memory { get; init; }
	public PerformanceChunkMetrics Chunks { get; init; }
	public PerformanceMeshingMetrics Meshing { get; init; }
	public PerformanceVisibilityMetrics Visibility { get; init; }
	public PerformanceSubmissionMetrics Submission { get; init; }
	public PerformanceStreamingMetrics Streaming { get; init; }
	public PerformanceBoundsMetrics Bounds { get; init; }
	public PerformanceProfilerMetrics Profiler { get; init; }
	public PerformanceHierarchyMetrics Hierarchy { get; init; }
	public IReadOnlyList<PerformanceLevelMetrics> Levels { get; init; } =
		System.Array.Empty<PerformanceLevelMetrics>();
	public IReadOnlyList<PerformanceTransitionPairMetrics> TransitionPairs { get; init; } =
		System.Array.Empty<PerformanceTransitionPairMetrics>();
	public PerformanceOuterWorkMetrics OuterWork { get; init; }
}

internal sealed class PerformanceOuterWorkMetrics
{
	public long Scheduled { get; init; }
	public long Published { get; init; }
	public long Cancelled { get; init; }
	public long Superseded { get; init; }
	public long OpportunisticServices { get; init; }
	public long ForcedServices { get; init; }
	public float MaximumEligibleServiceGapMilliseconds { get; init; }
	public PerformanceQueueDepthMetrics QueueDepth { get; init; }
	public PerformanceLatencyMetrics ScheduleToRenderable { get; init; }
}

internal sealed class PerformanceTransitionPairMetrics
{
	public int FineLevel { get; init; }
	public int CoarseLevel { get; init; }
	public int Desired { get; init; }
	public int Ready { get; init; }
	public int Drawable { get; init; }
	public int Pending { get; init; }
	public int LastEntered { get; init; }
	public int LastLeft { get; init; }
	public int LastRetained { get; init; }
	public long Entered { get; init; }
	public long Left { get; init; }
	public long Scheduled { get; init; }
	public long Published { get; init; }
	public long Cancelled { get; init; }
	public long Stale { get; init; }
	public long ActiveCells { get; init; }
	public long Vertices { get; init; }
	public long Indices { get; init; }
	public long Triangles { get; init; }
	public long UsedVertexBytes { get; init; }
	public long UsedIndexBytes { get; init; }
	public string TopologyDigest { get; init; }
	public string PositionDigest { get; init; }
	public uint FineFaceMismatchCount { get; init; }
	public uint CoarseFaceMismatchCount { get; init; }
	public uint LateralEdgeDigest { get; init; }
	public uint LateralMismatchCount { get; init; }
	public uint InvalidTableCount { get; init; }
	public IReadOnlyList<PerformanceTransitionFaceMetrics> Faces { get; init; } =
		System.Array.Empty<PerformanceTransitionFaceMetrics>();
	public PerformanceDistributionMetrics ScheduleToPublication { get; init; }
}

internal sealed class PerformanceTransitionFaceMetrics
{
	public int FineLevel { get; init; }
	public int CoarseLevel { get; init; }
	public PerformanceVector3Int CoarseCoordinate { get; init; }
	public string Face { get; init; }
	public uint Generation { get; init; }
	public int Arena { get; init; }
	public int Slot { get; init; }
	public int VertexOffset { get; init; }
	public int VertexCount { get; init; }
	public int IndexOffset { get; init; }
	public int IndexCount { get; init; }
	public uint ActiveCells { get; init; }
	public float ScheduleToPublicationMilliseconds { get; init; }
	public string TopologyDigest { get; init; }
	public string PositionDigest { get; init; }
	public uint FineFaceMismatchCount { get; init; }
	public uint CoarseFaceMismatchCount { get; init; }
	public uint MinimumUDigest { get; init; }
	public uint MaximumUDigest { get; init; }
	public uint MinimumVDigest { get; init; }
	public uint MaximumVDigest { get; init; }
	public uint InvalidTableCount { get; init; }
}

internal sealed class PerformanceHierarchyMetrics
{
	public bool PlacementPending { get; init; }
	public int MaximumPlacementLevelLag { get; init; }
	public long RequestedVisualConfigurationRevision { get; init; }
	public long StagedVisualConfigurationRevision { get; init; }
	public long AppliedVisualConfigurationRevision { get; init; }
	public long PlacementRequests { get; init; }
	public long PlacementCommits { get; init; }
	public long PlacementSuperseded { get; init; }
	public long PlacementDeferredUpdates { get; init; }
	public long PlacementReadinessBlocks { get; init; }
	public long PlacementUnsafeCommits { get; init; }
	public float ClassificationMilliseconds { get; init; }
	public float MaximumClassificationMilliseconds { get; init; }
	public int GameplayCoordinates { get; init; }
	public int GameplayPending { get; init; }
	public int TransitionDesired { get; init; }
	public int TransitionReady { get; init; }
	public int TransitionDrawable { get; init; }
	public int TransitionPending { get; init; }
	public long TransitionActiveCells { get; init; }
	public long TransitionVertices { get; init; }
	public long TransitionIndices { get; init; }
	public string TransitionTopologyDigest { get; init; }
	public string TransitionPositionDigest { get; init; }
	public uint TransitionFineFaceMismatchCount { get; init; }
	public uint TransitionCoarseFaceMismatchCount { get; init; }
	public uint TransitionLateralMismatchCount { get; init; }
	public uint TransitionInvalidTableCount { get; init; }
	public long TransitionEntered { get; init; }
	public long TransitionLeft { get; init; }
	public int LastTransitionEntered { get; init; }
	public int LastTransitionLeft { get; init; }
	public int LastTransitionRetained { get; init; }
}

internal sealed class PerformanceLevelMetrics
{
	public int Level { get; init; }
	public bool VisualEnabled { get; init; }
	public float CellSize { get; init; }
	public float RegionSize { get; init; }
	public PerformanceVector3Int Anchor { get; init; }
	public PerformanceVector3Int OuterAnchor { get; init; }
	public PerformanceVector3Int OuterMinimum { get; init; }
	public PerformanceVector3Int OuterMaximum { get; init; }
	public PerformanceVector3Int HoleMinimum { get; init; }
	public PerformanceVector3Int HoleMaximum { get; init; }
	public int CachedCoordinates { get; init; }
	public int ActiveCoordinates { get; init; }
	public int Resident { get; init; }
	public int Pending { get; init; }
	public int FullUpdates { get; init; }
	public int IncrementalUpdates { get; init; }
	public long EnteredRegions { get; init; }
	public long LeftRegions { get; init; }
	public long ActivatedRegions { get; init; }
	public long DeactivatedRegions { get; init; }
	public int LastEnteredRegions { get; init; }
	public int LastLeftRegions { get; init; }
	public int LastActivatedRegions { get; init; }
	public int LastDeactivatedRegions { get; init; }
	public long ClassificationQueries { get; init; }
	public long RejectedSolid { get; init; }
	public long RejectedAir { get; init; }
	public long PotentiallySurfaceContaining { get; init; }
	public long Scheduled { get; init; }
	public long Published { get; init; }
	public long Cancelled { get; init; }
	public long Superseded { get; init; }
	public PerformanceLatencyMetrics ScheduleToRenderable { get; init; }
	public float AverageResidentMeshChunks { get; init; }
	public float AverageVisibleMeshChunks { get; init; }
	public uint SettledSurfaceMeshes { get; init; }
	public string TopologyDigest { get; init; }
	public string PositionDigest { get; init; }
}

internal sealed class PerformanceBoundsMetrics
{
	public int WarmQueries { get; set; }
	public int WarmDefinitelySolid { get; set; }
	public int WarmDefinitelyAir { get; set; }
	public int WarmPotentiallySurfaceContaining { get; set; }
	public float TotalCpuMilliseconds { get; set; }
	public float MaximumQueryMilliseconds { get; set; }
	public int StaleOrCancelledQueries { get; set; }
}

internal sealed class PerformanceSubmissionMetrics
{
	public float AverageTerrainIndirectApiSubmissionsPerFrame { get; init; }
	public int MaximumTerrainIndirectApiSubmissionsPerFrame { get; init; }
	public float AverageIndirectArgumentRecordsPerFrame { get; init; }
	public int MaximumIndirectArgumentRecordsPerFrame { get; init; }
	public float AverageTerrainBufferGroups { get; init; }
	public int MaximumTerrainBufferGroups { get; init; }
}

internal sealed class PerformanceProfilerMetrics
{
	public int WindowFrames { get; init; }
	public IReadOnlyList<PerformanceProfilerTiming> Engine { get; init; } =
		System.Array.Empty<PerformanceProfilerTiming>();
	public IReadOnlyList<PerformanceProfilerTiming> Scripts { get; init; } =
		System.Array.Empty<PerformanceProfilerTiming>();
}

internal sealed class PerformanceProfilerTiming
{
	public string Name { get; init; }
	public int Calls { get; init; }
	public float MinimumMillisecondsPerFrame { get; init; }
	public float AverageMillisecondsPerFrame { get; init; }
	public float P95MillisecondsPerFrame { get; init; }
	public float P99MillisecondsPerFrame { get; init; }
	public float MaximumMillisecondsPerFrame { get; init; }
}

internal sealed class PerformanceStreamingMetrics
{
	public long PreparationResultsDroppedOnMovement { get; set; }
	public long PreparationResultsRetainedOnMovement { get; set; }
	public long PreparationIntegrated { get; set; }
	public double PreparationIntegrationMilliseconds { get; set; }
	public long PlacementCacheCoordinatesScanned { get; set; }
	public long PlacementLevelsSkipped { get; set; }
	public double PlacementPreparationMilliseconds { get; set; }
	public float MaximumPlacementPreparationMilliseconds { get; set; }
	public int FullUpdates { get; set; }
	public int IncrementalUpdates { get; set; }
	public float TotalSynchronousMilliseconds { get; set; }
	public float MaximumSynchronousMilliseconds { get; set; }
	public float TotalDesiredUpdateMilliseconds { get; set; }
	public float TotalPrioritizationMilliseconds { get; set; }
	public float TotalDrawCommitMilliseconds { get; set; }
	public int DrawRebuilds { get; set; }
	public long GameplayCoordinatesTouched { get; set; }
	public long RenderCoordinatesTouched { get; set; }
	public int WarmCoordinatesClassified { get; set; }
	public int WarmRejectedSolid { get; set; }
	public int WarmRejectedAir { get; set; }
	public int WarmPotentiallySurfaceContaining { get; set; }
	public int WarmTransientChunksConstructed { get; set; }
	public int PeakGameplayMeshBacklog { get; set; }
	public int PeakWarmMeshBacklog { get; set; }
}

internal sealed class PerformanceTestSource
{
	public string Task { get; init; }
	public string Revision { get; init; }
}

internal sealed class PerformanceTestDefinition
{
	public string Name { get; init; }
	public int CompletedLoops { get; init; }
	public float Speed { get; init; }
	public float Distance { get; init; }
	public float TerrainClearance { get; init; }
	public float DurationSeconds { get; init; }
	public PerformanceVector2 StartCenter { get; init; }
}

internal sealed class PerformanceWorldContext
{
	public string Scene { get; init; }
	public int CellsPerAxis { get; init; }
	public float BaseCellSize { get; init; }
	public int GameplayRadius { get; init; }
	public int VisualChunkRadius { get; init; }
	public int MinimumVisualLod { get; init; }
	public int MaximumVisualLod { get; init; }
	public int Lod0VisualHalfExtent { get; init; }
	public int LodCacheHalfExtent { get; init; }
	public long VisualConfigurationRevision { get; init; }
	public string Generator { get; init; }
	public int WorldSeed { get; init; }
	public int GeneratorVersion { get; init; }
	public ProceduralTerrainSettings TerrainSettings { get; init; }
	public PerformanceVector3Int StreamingCenter { get; init; }
	public PerformanceVector3 TargetPosition { get; init; }
}

internal sealed class PerformanceFrameMetrics
{
	public int Samples { get; init; }
	public int TruncatedSamples { get; init; }
	public float AverageFps { get; init; }
	public float P95Milliseconds { get; init; }
	public float P99Milliseconds { get; init; }
	public float? MaximumMilliseconds { get; init; }
	public float AverageGpuMilliseconds { get; init; }
	public float P95GpuMilliseconds { get; init; }
	public float P99GpuMilliseconds { get; init; }
	public float MaximumGpuMilliseconds { get; init; }
}

internal sealed class PerformanceStationaryMetrics
{
	public float DurationSeconds { get; init; }
	public PerformanceFrameMetrics Frame { get; init; }
	public PerformanceRuntimeMetrics Runtime { get; init; }
	public PerformanceMemoryMetrics Memory { get; init; }
	public PerformanceProfilerMetrics Profiler { get; init; }
	public PerformanceVisibilityMetrics Visibility { get; init; }
}

internal sealed class PerformanceRuntimeMetrics
{
	public int Samples { get; init; }
	public long ManagedBytesAllocated { get; init; }
	public float AverageManagedBytesAllocatedPerFrame { get; init; }
	public long MaximumManagedBytesAllocatedPerFrame { get; init; }
	public int Gen0Collections { get; init; }
	public int Gen1Collections { get; init; }
	public int Gen2Collections { get; init; }
	public int FramesWithCollections { get; init; }
	public float GcPauseMilliseconds { get; init; }
	public float MaximumGcPauseMilliseconds { get; init; }
	public int Exceptions { get; init; }
	public int FramesWithExceptions { get; init; }
}

internal sealed class PerformanceMemoryMetrics
{
	public ulong StartProcessBytes { get; init; }
	public ulong EndProcessBytes { get; init; }
	public ulong AverageProcessBytes { get; init; }
	public ulong PeakProcessBytes { get; init; }
	public ulong StartGpuBytes { get; init; }
	public ulong EndGpuBytes { get; init; }
	public ulong AverageGpuBytes { get; init; }
	public ulong PeakGpuBytes { get; init; }
	public ulong GpuBudgetBytes { get; init; }
}

internal sealed class PerformanceChunkMetrics
{
	// Logical implicit-SDF membership is distinct from prepared or GPU-resident regions.
	public int Loaded { get; init; }
	public int Pending { get; init; }
	public long Prepared { get; init; }
	public float PreparedPerSecond { get; init; }
	public float LastRangeUpdateMilliseconds { get; init; }
}

internal sealed class PerformanceMeshingMetrics
{
	public long CancelledRegularCountResults { get; init; }
	public long CancelledTransitionCountResults { get; init; }
	public long SkippedRegularGeometryRegions { get; init; }
	public long SkippedTransitionGeometryRegions { get; init; }
	public long EmptyBatchSubmissionsAvoided { get; init; }
	public int ConfiguredMaximumDispatchesPerUpdate { get; init; }
	public int ObservedMaximumDispatchesPerUpdate { get; init; }
	public long Dispatches { get; init; }
	public int Resident { get; init; }
	public int GameplayResident { get; init; }
	public int WarmResident { get; init; }
	public int Pending { get; init; }
	public int AllPending { get; init; }
	public int GameplayPending { get; init; }
	public int WarmPending { get; init; }
	public int NearVisualPending { get; init; }
	public int OuterVisualPending { get; init; }
	public int PoolAvailable { get; init; }
	public long LogicalCapacityBytes { get; init; }
	public long ReservedActiveCellCapacity { get; init; }
	public long ReservedActiveCellCapacityBytes { get; init; }
	public int SettledSlabs { get; init; }
	public uint SettledSurfaceMeshes { get; init; }
	public uint SettledWarmSurfaceMeshes { get; init; }
	public uint TotalActiveCells { get; init; }
	public float AverageActiveCellsPerSurfaceChunk { get; init; }
	public uint MaximumActiveCellsPerSurfaceChunk { get; init; }
	public float ActiveCellUtilizationPercent { get; init; }
	public long PoolAllocations { get; init; }
	public long PoolReuses { get; init; }
	public long? GameThreadAllocatedBytes { get; init; }
	public long ScalarReadbacks { get; init; }
	public long GeometryReadbacks { get; init; }
	public long OrdinaryRenderSdfEvaluations { get; init; }
	public long UniqueVertices { get; init; }
	public long Triangles { get; init; }
	public long Indices { get; init; }
	public long UsedVertexBytes { get; init; }
	public long UsedIndexBytes { get; init; }
	public long CommittedVertexBytes { get; init; }
	public long CommittedIndexBytes { get; init; }
	public int ArenaCount { get; init; }
	public int FreeRangeCount { get; init; }
	public int LargestFreeVertexRange { get; init; }
	public int LargestFreeIndexRange { get; init; }
	public float FragmentationPercent { get; init; }
	public long TransientScratchBytes { get; init; }
	public long DedicatedOuterTransientScratchBytes { get; init; }
	public long TransitionTransientScratchBytes { get; init; }
	public long AllocationCountReadbacks { get; init; }
	public long AllocationCountReadbackBytes { get; init; }
	public double AllocationCountReadbackMilliseconds { get; init; }
	public long TransitionCountReadbacks { get; init; }
	public double TransitionCountReadbackMilliseconds { get; init; }
	public double TransitionCountCallbackWaitMilliseconds { get; init; }
	public double TransitionMaximumCountReadbackMilliseconds { get; init; }
	public double TransitionMaximumCountCallbackWaitMilliseconds { get; init; }
	public double CountStageSubmissionMilliseconds { get; init; }
	public double EmitStageSubmissionMilliseconds { get; init; }
	public string TopologyDigest { get; init; }
	public string PositionDigest { get; init; }
	public string GpuProfilerPath { get; init; }
	public float AverageGpuMilliseconds { get; init; }
	public float MaximumGpuMilliseconds { get; init; }
	public PerformanceLatencyMetrics ScheduleToRenderable { get; init; }
	public PerformanceMeshingThroughputMetrics Throughput { get; init; }
	public long RegularCountBatches { get; init; }
	public long RegularCountRegions { get; init; }
	public long RegularEmitArenaPasses { get; init; }
	public long RegularEmitBatchSlots { get; init; }
	public long RegularEnabledEmitRegions { get; init; }
	public long RegularMultiArenaBatches { get; init; }
	public long TransitionDeferredRenderTicks { get; init; }
}

internal sealed class PerformanceMeshingThroughputMetrics
{
	public int ScratchLanes { get; init; }
	public long RegionsScheduled { get; init; }
	public long RegionsCountSubmitted { get; init; }
	public long RegionsPublished { get; init; }
	public float RegionsScheduledPerSecond { get; init; }
	public float RegionsCountSubmittedPerSecond { get; init; }
	public float RegionsPublishedPerSecond { get; init; }
	public long BatchesSubmitted { get; init; }
	public long BatchesCompleted { get; init; }
	public float BatchesSubmittedPerSecond { get; init; }
	public float BatchesCompletedPerSecond { get; init; }
	public float AverageBatchOccupancy { get; init; }
	public int MinimumBatchOccupancy { get; init; }
	public int MaximumBatchOccupancy { get; init; }
	public IReadOnlyList<int> BatchOccupancyHistogram { get; init; } = System.Array.Empty<int>();
	public PerformanceDistributionMetrics CountSubmissionMilliseconds { get; init; }
	public PerformanceDistributionMetrics CountReadbackMilliseconds { get; init; }
	public PerformanceDistributionMetrics CountCallbackWaitMilliseconds { get; init; }
	public PerformanceDistributionMetrics CpuAllocationMilliseconds { get; init; }
	public PerformanceDistributionMetrics EmitSubmissionMilliseconds { get; init; }
	public PerformanceDistributionMetrics EmitToPublicationMilliseconds { get; init; }
	public PerformanceQueueDepthMetrics GameplayQueue { get; init; }
	public PerformanceQueueDepthMetrics WarmQueue { get; init; }
	public PerformanceQueueDepthMetrics TotalQueue { get; init; }
	public PerformanceDistributionMetrics PlayerRouteLagWorldUnits { get; init; }
	public PerformanceDistributionMetrics PlayerRouteLagChunks { get; init; }
	public float PostLoopDrainMilliseconds { get; init; }
}

// Nearest-rank tails of sorted retained samples. Collection, overflow and means
// belong to the caller; this value does not own or copy sample storage.
internal readonly record struct PerformanceSampleTails( float P50, float P95, float P99, float Maximum )
{
	public static PerformanceSampleTails FromSorted( ReadOnlySpan<float> values )
	{
		if ( values.IsEmpty ) return default;
		return new PerformanceSampleTails(
			values[(int)Math.Ceiling( values.Length * 0.50d ) - 1],
			values[(int)Math.Ceiling( values.Length * 0.95d ) - 1],
			values[(int)Math.Ceiling( values.Length * 0.99d ) - 1],
			values[^1] );
	}
}

internal sealed class PerformanceDistributionMetrics
{
	public int Samples { get; init; }
	public int TruncatedSamples { get; init; }
	public float Average { get; init; }
	public float P50 { get; init; }
	public float P95 { get; init; }
	public float P99 { get; init; }
	public float Maximum { get; init; }
}

internal sealed class PerformanceQueueDepthMetrics
{
	public int Samples { get; init; }
	public int TruncatedSamples { get; init; }
	public float Average { get; init; }
	public float P50 { get; init; }
	public float P95 { get; init; }
	public float P99 { get; init; }
	public int Maximum { get; init; }
}

internal sealed class PerformanceLatencyMetrics
{
	public int Samples { get; init; }
	public int TruncatedSamples { get; init; }
	public float P50Milliseconds { get; init; }
	public float P95Milliseconds { get; init; }
	public float P99Milliseconds { get; init; }
	public float MaximumMilliseconds { get; init; }
	public int Cancelled { get; init; }
	public int Superseded { get; init; }
}

internal sealed class PerformanceVisibilityMetrics
{
	public uint Samples { get; init; }
	public float AverageResidentMeshChunks { get; init; }
	public float AverageVisibleMeshChunks { get; init; }
	public float AverageWarmMeshChunks { get; init; }
	public uint MinimumVisibleMeshChunks { get; init; }
	public uint MaximumVisibleMeshChunks { get; init; }
	public float AverageNonZeroIndirectDraws { get; init; }
	public float AverageCulledDraws { get; init; }
	public float CulledDrawPercentage { get; init; }
	public long LogicalBufferBytes { get; init; }
	public long ScalarReadbacks { get; init; }
}

internal sealed class PerformanceVector2
{
	public float X { get; init; }
	public float Y { get; init; }
}

internal sealed class PerformanceVector3
{
	public float X { get; init; }
	public float Y { get; init; }
	public float Z { get; init; }
}

internal sealed class PerformanceVector3Int
{
	public int X { get; init; }
	public int Y { get; init; }
	public int Z { get; init; }
}

internal sealed class PerformanceCollisionMetrics
{
	public int Desired { get; init; }
	public int Ready { get; init; }
	public int Bodies { get; init; }
	public int Pending { get; init; }
	public bool Building { get; init; }
	public int ActiveWorkers { get; init; }
	public int WorkerLimit { get; init; }
	public int Completed { get; init; }
	public int Retiring { get; init; }
	public int Failures { get; init; }
	public int StaleDiscarded { get; init; }
	public int Published { get; init; }
	public int PeakCompleted { get; init; }
	public long PeakCompletedBytes { get; init; }
	public long ResidentGeometryBytes { get; init; }
	public long PeakResidentGeometryBytes { get; init; }
	public long DegenerateTriangles { get; init; }
	public long WeldedIntersections { get; init; }
	public long SupportPatchRebuilds { get; init; }
	public long SampleCount { get; init; }
	public long RejectedBlocks { get; init; }
	public PerformanceDistributionMetrics Sampling { get; init; }
	public PerformanceDistributionMetrics Extraction { get; init; }
	public PerformanceDistributionMetrics Creation { get; init; }
	public PerformanceDistributionMetrics MeshCreation { get; init; }
	public float WorstCreationSetupMilliseconds { get; init; }
	public float WorstCreationMeshMilliseconds { get; init; }
	public float WorstCreationPublicationMilliseconds { get; init; }
	public PerformanceVector3Int WorstCreationCoordinate { get; init; }
	public int WorstCreationVertices { get; init; }
	public int WorstCreationIndices { get; init; }
	public PerformanceDistributionMetrics Retirement { get; init; }
	public PerformanceDistributionMetrics RequestToReady { get; init; }
}
