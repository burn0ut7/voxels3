// GPU mirror of TerrainCliffs. Positive values remove solid terrain.
float SampleVoxelCliffs( float3 position, float4 terrain, float4 scales, float seaLevel, float mountainWeight )
{
	float limit = scales.w;
	float mask = (mountainWeight - 0.75) * limit;
	float value = -3.402823466e+38;
	if ( mask <= -limit * 0.25 || position.z < seaLevel + limit * 0.08 || position.z > seaLevel + limit * 0.78 )
	{
		return value;
	}
	float scale = scales.z * 1.3;
	int2 origin = (int2)floor( position.xy / scale );
	uint seed = (uint)(int)terrain.x;
	[unroll]
	for ( int y = -1; y <= 1; y++ )
	{
		[unroll]
		for ( int x = -1; x <= 1; x++ )
		{
			int2 cell = origin + int2( x, y );
			uint a = VoxelHash2D( cell.x, cell.y, seed ^ 0xE19B01AAu );
			uint b = VoxelHash2D( cell.x, cell.y, seed ^ 0xC734D891u );
			if ( (a >> 24) >= 128u )
			{
				float2 axis = float2( (b & 255u) - 127.5, ((b >> 8) & 255u) - 127.5 );
				axis /= sqrt( dot( axis, axis ) );
				float2 center = ((float2)cell + 0.5 + (float2( a & 255u, (a >> 8) & 255u ) / 255.0 - 0.5) * 0.36) * scale;
				float radiusX = scale * (0.22 + 0.12 * ((a >> 16) & 255u) / 255.0);
				float radiusY = scale * 0.14;
				float zCenter = seaLevel + limit * (0.28 + 0.30 * ((b >> 16) & 255u) / 255.0);
				float halfHeight = limit * (0.12 + 0.08 * (b >> 24) / 255.0);
				float2 delta = position.xy - center;
				float u = abs( delta.x * axis.x + delta.y * axis.y );
				float v = abs( -delta.x * axis.y + delta.y * axis.x );
				float vertical = halfHeight - abs( position.z - zCenter );
				float recess = 64.0 * clamp( vertical / halfHeight, 0.0, 1.0 );
				float horizontal = (1.0 - sqrt( u * u / (radiusX * radiusX) + v * v / (radiusY * radiusY) )) * min( radiusX, radiusY ) + recess;
				value = max( value, min( horizontal, vertical ) );
			}
		}
	}
	return min( value, mask );
}


