using System;

/// <summary>Seeded compact peak forms, their analytic slope, and conservative bounds.</summary>
internal static class MountainMasses
{
	// In cell units. The rounded tip keeps guidance continuous at each summit.
	private const float TipSquared = 0.0004f;
	private const float ConeSpan = 0.98019998f;
	private readonly record struct Peak( Vector2 Center, Vector2 Axis, float Major, float Minor, float Height );

	private static Peak At( int x, int y, uint seed )
	{
		var a = TerrainNoise.Hash( x, y, seed ^ 0x7F4A7C15u );
		var b = TerrainNoise.Hash( x, y, seed ^ 0x94D049BBu );
		var axisX = (b & 255u) - 127.5f;
		var axisY = ((b >> 8) & 255u) - 127.5f;
		var axisLength = MathF.Sqrt( axisX * axisX + axisY * axisY );
		return new Peak(
			new Vector2( x + 0.5f + ((a & 255u) / 255f - 0.5f) * 0.36f,
				y + 0.5f + (((a >> 8) & 255u) / 255f - 0.5f) * 0.36f ),
			new Vector2( axisX / axisLength, axisY / axisLength ),
			0.85f + 0.30f * ((a >> 24) & 255u) / 255f,
			0.60f + 0.25f * ((b >> 16) & 255u) / 255f,
			0.60f + 0.40f * ((a >> 16) & 255u) / 255f );
	}

	public static float Sample( Vector3 position, float scale, uint seed, out Vector2 gradient, out float peakFraction )
	{
		var point = new Vector2( position.x / scale, position.y / scale );
		var cellX = (int)MathF.Floor( point.x );
		var cellY = (int)MathF.Floor( point.y );
		var mass = 0f;
		gradient = default;
		peakFraction = 0f;
		// Support <=1.15 and jitter <=.18: omitted cells are >=1.32 away.
		for ( var y = -1; y <= 1; y++ )
		{
			for ( var x = -1; x <= 1; x++ )
			{
				var peak = At( cellX + x, cellY + y, seed );
				var delta = point - peak.Center;
				var u = (delta.x * peak.Axis.x + delta.y * peak.Axis.y) / peak.Major;
				var v = (-delta.x * peak.Axis.y + delta.y * peak.Axis.x) / peak.Minor;
				var radiusSquared = u * u + v * v;
				if ( radiusSquared >= 1f )
				{
					continue;
				}
				var radius = MathF.Sqrt( radiusSquared + TipSquared );
				var cone = Math.Clamp( (1.00019998f - radius) / ConeSpan, 0f, 1f );
				// Local summit fraction ignores the individual peak height.
				peakFraction = MathF.Max( peakFraction, cone * cone );
				var height = peak.Height * cone * cone;
				var radialGradient = new Vector2(
					u * peak.Axis.x / peak.Major - v * peak.Axis.y / peak.Minor,
					u * peak.Axis.y / peak.Major + v * peak.Axis.x / peak.Minor );
				var peakGradient = radialGradient * (-2f * peak.Height * cone / (radius * ConeSpan * scale));
				// Smooth union: 1-product(1-peak), bounded by [0,1].
				gradient = gradient * (1f - height) + peakGradient * (1f - mass);
				mass += (1f - mass) * height;
			}
		}
		return mass;
	}

	public static (double Minimum, double Maximum) Bound( SdfWorldAabb bounds, float scale, uint seed )
	{
		var minX = (double)bounds.Minimum.x / scale;
		var minY = (double)bounds.Minimum.y / scale;
		var maxX = (double)bounds.Maximum.x / scale;
		var maxY = (double)bounds.Maximum.y / scale;
		// Include float division/center arithmetic at large world coordinates.
		var padding = 0.0001d + Math.Max( Math.Max( Math.Abs( minX ), Math.Abs( maxX ) ),
			Math.Max( Math.Abs( minY ), Math.Abs( maxY ) ) ) * 0.000001d;
		minX -= padding;
		minY -= padding;
		maxX += padding;
		maxY += padding;
		var cellX = (int)Math.Floor( minX );
		var cellY = (int)Math.Floor( minY );
		if ( cellX != (int)Math.Floor( maxX ) || cellY != (int)Math.Floor( maxY ) )
		{
			return (0d, 1d);
		}
		var centerX = (minX + maxX) * 0.5d;
		var centerY = (minY + maxY) * 0.5d;
		var halfX = (maxX - minX) * 0.5d;
		var halfY = (maxY - minY) * 0.5d;
		var emptyMinimum = 1d;
		var emptyMaximum = 1d;
		for ( var y = -1; y <= 1; y++ )
		{
			for ( var x = -1; x <= 1; x++ )
			{
				var peak = At( cellX + x, cellY + y, seed );
				var dx = centerX - peak.Center.x;
				var dy = centerY - peak.Center.y;
				var u = Math.Abs( (dx * peak.Axis.x + dy * peak.Axis.y) / peak.Major );
				var v = Math.Abs( (-dx * peak.Axis.y + dy * peak.Axis.x) / peak.Minor );
				var ru = (halfX * Math.Abs( peak.Axis.x ) + halfY * Math.Abs( peak.Axis.y )) / peak.Major;
				var rv = (halfX * Math.Abs( peak.Axis.y ) + halfY * Math.Abs( peak.Axis.x )) / peak.Minor;
				var nearU = Math.Max( 0d, u - ru );
				var nearV = Math.Max( 0d, v - rv );
				var farU = u + ru;
				var farV = v + rv;
				var coneMinimum = Math.Clamp( (1.00019998d - Math.Sqrt( farU * farU + farV * farV + TipSquared )) / ConeSpan, 0d, 1d );
				var coneMaximum = Math.Clamp( (1.00019998d - Math.Sqrt( nearU * nearU + nearV * nearV + TipSquared )) / ConeSpan, 0d, 1d );
				emptyMinimum *= 1d - peak.Height * coneMaximum * coneMaximum;
				emptyMaximum *= 1d - peak.Height * coneMinimum * coneMinimum;
			}
		}
		return (1d - emptyMaximum, 1d - emptyMinimum);
	}
}
