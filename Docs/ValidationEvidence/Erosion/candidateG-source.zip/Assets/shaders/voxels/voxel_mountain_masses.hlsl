// GPU mirror of MountainMasses. Compact peak support, shape and hash salts are owned there.
float SampleVoxelMountainMass( float2 position, float scale, uint seed, out float2 gradient, out float peakFraction )
{
	float2 point = position / scale;
	int2 origin = (int2)floor( point );
	float mass = 0.0;
	gradient = float2( 0.0, 0.0 );
	peakFraction = 0.0;
	[unroll]
	for ( int y = -1; y <= 1; y++ )
	{
		[unroll]
		for ( int x = -1; x <= 1; x++ )
		{
			int2 cell = origin + int2( x, y );
			uint a = VoxelHash2D( cell.x, cell.y, seed ^ 0x7F4A7C15u );
			uint b = VoxelHash2D( cell.x, cell.y, seed ^ 0x94D049BBu );
			float2 axis = float2( (b & 255u) - 127.5, ((b >> 8) & 255u) - 127.5 );
			axis /= sqrt( dot( axis, axis ) );
			float2 center = (float2)cell + 0.5 + (float2( a & 255u, (a >> 8) & 255u ) / 255.0 - 0.5) * 0.36;
			float major = 0.85 + 0.30 * ((a >> 24) & 255u) / 255.0;
			float minor = 0.60 + 0.25 * ((b >> 16) & 255u) / 255.0;
			float peakHeight = 0.60 + 0.40 * ((a >> 16) & 255u) / 255.0;
			float2 delta = point - center;
			float u = (delta.x * axis.x + delta.y * axis.y) / major;
			float v = (-delta.x * axis.y + delta.y * axis.x) / minor;
			float radiusSquared = u * u + v * v;
			[branch]
			if ( radiusSquared < 1.0 )
			{
				float radius = sqrt( radiusSquared + 0.0004 );
				float cone = clamp( (1.00019998 - radius) / 0.98019998, 0.0, 1.0 );
				peakFraction = max( peakFraction, cone * cone );
				float height = peakHeight * cone * cone;
				float2 radialGradient = float2( u * axis.x / major - v * axis.y / minor,
					u * axis.y / major + v * axis.x / minor );
				float2 peakGradient = radialGradient * (-2.0 * peakHeight * cone / (radius * 0.98019998 * scale));
				gradient = gradient * (1.0 - height) + peakGradient * (1.0 - mass);
				mass += (1.0 - mass) * height;
			}
		}
	}
	return mass;
}
