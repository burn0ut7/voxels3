import json,hashlib,time
from pathlib import Path
import numpy as np
from PIL import Image
root=Path.cwd()
out=Path(__file__).parent/'compressed-grass'
out.mkdir(exist_ok=True)
size=8192
period=4
src=root/'Assets/textures/grass/grass004'
paths={k:src/('Grass004_2K-PNG_'+v+'.png') for k,v in [('color','Color'),('normal','NormalGL'),('roughness','Roughness'),('ao','AmbientOcclusion')]}
color=np.asarray(Image.open(paths['color']).convert('RGB'),dtype=np.float32)/255
color=np.where(color<=.04045,color/12.92,((color+.055)/1.055)**2.4)
normal=np.asarray(Image.open(paths['normal']).convert('RGB'),dtype=np.float32)/255*2-1
normal/=np.maximum(np.linalg.norm(normal,axis=2,keepdims=True),1e-8)
rough=np.asarray(Image.open(paths['roughness']).convert('L'),dtype=np.float32)/255
ao=np.asarray(Image.open(paths['ao']).convert('L'),dtype=np.float32)/255
assert color.shape[:2]==normal.shape[:2]==rough.shape==ao.shape
source=np.concatenate([color,normal,rough[...,None],ao[...,None]],axis=2)
height,width=source.shape[:2]
outputs={'color':np.empty((size,size,3),np.uint8),'normal':np.empty((size,size,3),np.uint8),'roughness':np.empty((size,size),np.uint8),'ao':np.empty((size,size),np.uint8)}
del color,normal,rough,ao

def sample(u,v):
 x=(u%1)*width-.5;y=(v%1)*height-.5
 ix=np.floor(x).astype(np.int32);iy=np.floor(y).astype(np.int32)
 fx=(x-ix).astype(np.float32)[...,None];fy=(y-iy).astype(np.float32)[...,None]
 a=source[iy%height,ix%width]*(1-fx)+source[iy%height,(ix+1)%width]*fx
 b=source[(iy+1)%height,ix%width]*(1-fx)+source[(iy+1)%height,(ix+1)%width]*fx
 return a*(1-fy)+b*fy

def encode(v):return np.rint(np.clip(v,0,1)*255).astype(np.uint8)

t0=time.time()
for first in range(0,size,64):
 lx=np.broadcast_to((np.arange(size,dtype=np.float32)+.5)*period/size,(min(64,size-first),size))
 ly=np.broadcast_to(((np.arange(first,min(first+64,size),dtype=np.float32)+.5)*period/size)[:,None],lx.shape)
 cx=np.floor(lx);cy=np.floor(ly);fx=lx-cx;fy=ly-cy
 lower=fx+fy<=1
 blend=np.stack([np.where(lower,1-fx-fy,fx+fy-1),np.where(lower,fx,1-fx),np.where(lower,fy,1-fy)],axis=2)
 blend*=blend;blend*=blend
 blend=np.maximum(blend-.001,0);blend/=blend.sum(axis=2,keepdims=True)
 ux=lx+.5*ly;uy=ly*np.float32(.8660254037844386)
 total=np.zeros((*lx.shape,8),np.float32)
 for patch in range(3):
  if patch==0:vx=cx+~lower;vy=cy+~lower
  elif patch==1:vx=cx+lower;vy=cy+~lower
  else:vx=cx+~lower;vy=cy+lower
  kx=(vx.astype(np.int32)%period).astype(np.uint32)
  ky=(vy.astype(np.int32)%period).astype(np.uint32)
  h=(kx*np.uint32(0x8DA6B343))^(ky*np.uint32(0xD8163841))
  h^=h>>16;h*=np.uint32(0x7FEB352D);h^=h>>15
  ox=(h&65535).astype(np.float32)/65536
  oy=(h>>16).astype(np.float32)/65536
  su=ux-vx-.5*vy+ox;sv=uy-vy*np.float32(.8660254037844386)+oy
  total+=sample(su,sv)*blend[...,patch,None]
 rgb=total[...,:3]
 rgb=np.where(rgb<=.0031308,rgb*12.92,1.055*np.maximum(rgb,0)**(1/2.4)-.055)
 outputs['color'][first:first+len(lx)]=encode(rgb)
 outputs['normal'][first:first+len(lx)]=encode(total[...,3:6]*.5+.5)
 outputs['roughness'][first:first+len(lx)]=encode(total[...,6])
 outputs['ao'][first:first+len(lx)]=encode(total[...,7])
 if first%1024==0:print('rows',first,'elapsed',round(time.time()-t0,1),flush=True)
for name,a in outputs.items():
 target=out/('grass_'+name+'.png')
 Image.fromarray(a).save(target,compress_level=6)
 print(name,target.stat().st_size,flush=True)
manifest={'size':size,'period':period,'blendExponent':4,'blendCutoff':.001,'source':{k:{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in paths.items()},'output':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.png')},'seconds':time.time()-t0}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('done',round(time.time()-t0,1),flush=True)
